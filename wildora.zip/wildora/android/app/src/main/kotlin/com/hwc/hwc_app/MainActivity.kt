package com.hwc.hwc_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
